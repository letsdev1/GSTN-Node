/* 


    1. Add the specifications for all API calls. along with a key
        So far, keys are :
            api-auth ==> for authentication
            api-otp ==> for otp request

*/