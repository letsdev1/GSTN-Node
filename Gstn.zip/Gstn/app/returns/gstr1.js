var encryptionHelper=require('./crypto')
var helper = require('./helper');
var logger = require('./logs/logger');
var context = require('./shared/shared.context');
var api = require('./api.caller/api.entry');
var util = require('util');
var gstrOne = require('./gstn_models/gstr1');



module.exports.GSTR1 = {



    //Developer: Vikas B
    //Date: 9/29/2017 
    //Purpose: function for saving the gstr1 data to gstn portal.
    //the type will be gstn_models/gstr1.js

    saveData(gstr){

        

    }

}