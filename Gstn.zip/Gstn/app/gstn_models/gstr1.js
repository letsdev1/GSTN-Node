module.exports.gstr1=
{
  gstin: '', //
  fp: '',
  gt: 0.00,
  cur_gt: 0.00,
  b2b: [],
  b2cl: [],
  cdnr: [],
  b2cs: [],
  exp: [],
  hsn: {
    data: [] 
  },
  nil: undefined,
  txpd: [],
  at: [
    // {
    //   pos: '',
    //   sply_ty: '',
    //   itms: [
    //     {
    //       rt: 0,
    //       ad_amt: 0,
    //       iamt: 0,
    //       csamt: 0
    //     }
    //   ]
    // }
  ],
  doc_issue: {
    doc_det: [
      // {
      //   doc_num: 0,
      //   docs: [
      //     {
      //       num: 0,
      //       from: '',
      //       to: '',
      //       totnum: 0,
      //       cancel: 0,
      //       net_issue: 0
      //     }
      //   ]
      // }
    ]
  },
  cdnur: [
    // {
    //   typ: '',
    //   ntty: '',
    //   nt_num: '',
    //   nt_dt: '',
    //   p_gst: '',
    //   rsn: '',
    //   inum: '',
    //   idt: '',
    //   val: 0,
    //   itms: [
    //     // {
    //     //   num: 0,
    //     //   itm_det: {
    //     //     rt: 0,
    //     //     txval: 0.00,
    //     //     iamt: 0.00,
    //     //     csamt: 0.00
    //     //   }
    //     // }
    //   ]
    // }
  ]
}