module.exports.txpd=    {
      pos: '',
      sply_ty: '',
      itms: [
        {
          rt: 0,
          ad_amt: 0,
          iamt: 0,
          csamt: 0
        }
      ]
    }
