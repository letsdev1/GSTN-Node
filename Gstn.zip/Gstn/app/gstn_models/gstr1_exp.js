module.exports.exp=    {
      exp_typ: '',
      inv: [
        {
          inum: '',
          idt: '',
          val: 0,
          sbpcode: '',
          sbnum: 0,
          sbdt: '',
          itms: [
            {
              txval: 0,
              rt: 0,
              iamt: 0
            }
          ]
        }
      ]
    }
