module.exports.hsn=      {
        num: 1,
        hsn_sc: '',
        desc: '',
        uqc: '',
        qty: 0,
        val: 0.00,
        txval: 0.00,
        iamt: 0.00,
        csamt: 0
      }
