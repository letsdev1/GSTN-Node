module.exports.b2cl=
    {
      pos: '',
      inv:[ 
        {
          inum: '',
          idt: '',
          val: 0,
          etin: '',
          itms: [
            {
              num: 1,
              itm_det: {
                rt: 5,
                txval: 10000,
                iamt: 833.33,
                csamt: 500
              }
            }
          ]
        }
      ]
    }
  