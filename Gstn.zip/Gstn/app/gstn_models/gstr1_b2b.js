module.exports.b2b=    {
      ctin: '',
      inv: [{
          inum: '',
          idt: '1-1-1900', //date format
          val: 0,
          pos: '',
          rchrg: 'N',
          etin: '',
          inv_typ: '',
          itms: [{
              num: 0,
              itm_det: {
                rt: 0,
                txval: 0,
                iamt: 0,
                csamt: 0
              }
            }]      
        }]
    }
