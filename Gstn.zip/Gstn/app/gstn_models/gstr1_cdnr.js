module.exports.cdnr=    {
      ctin: '',
      nt: [
        {
          ntty: '',
          nt_num: '',
          nt_dt: '',
          p_gst: '',
          rsn: '',
          inum: '',
          idt: '',
          val: 0,
          itms: [
            {
              num: 0,
              itm_det: {
                rt: 0,
                txval: 0,
                iamt: 0,
                csamt: 0
              }
            }
          ]
        }
      ]
    }