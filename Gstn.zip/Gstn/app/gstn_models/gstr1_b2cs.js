module.exports.b2cs=    {
      sply_ty: '',
      rt: 0,
      typ: '',
      etin: '',
      pos: '',
      txval: 0,
      iamt: 0,
      csamt: 0
    }
