module.exports.nil={
    inv: [
      {
        sply_ty: '',
        expt_amt: 0.00,
        nil_amt: 0.00,
        ngsup_amt: 0.00
      }
    ]
  }