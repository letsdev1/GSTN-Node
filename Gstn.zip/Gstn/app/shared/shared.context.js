

module.exports.Context = {

    AppKey:'',
    AppKeyBytes:[],
    LoggedUser:'',
    DecipherBytes:[],
    AuthToken:'',
    sek:'',
    Decipher:''   
}
